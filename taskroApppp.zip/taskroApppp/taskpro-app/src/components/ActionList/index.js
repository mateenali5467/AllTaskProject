import React from 'react';
import {CardContainer} from "./styles";

const ActionList = () => {
  return (
    <CardContainer>

    </CardContainer>
  )
};

export default ActionList;
