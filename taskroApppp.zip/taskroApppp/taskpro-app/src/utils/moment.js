import instance from 'moment';

const moment = instance;

export {moment};
