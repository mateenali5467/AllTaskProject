export default {
  BASE_URL: `http://localhost:8000/api/v1`,
  AWS_URL: '',
  ONESIGNAL_APP: ''
}
